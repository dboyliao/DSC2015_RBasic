# Code placed in this file fill be executed every time the
# lesson is started. Any variables created here will show up in
# the user's working directory and thus be accessible to them
# throughout the lesson.
rm(list=ls())
hello <- "Hello"
world <- "World."
tenshia <- "天下之事,合久必分分久必合"
puff <- "郭雪芙"
takeshi <- "金城武"
months_ans <- c(1:12)
my_vec <- c("1", "2", "1", "1")
my_factor <- factor(my_vec)
